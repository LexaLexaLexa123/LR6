const question = document.getElementById("question");
const imageElement = document.getElementById("image");
const optionButtonsElement = document.getElementById("options-buttons");

// Функция , показывающая текст
function showQuestion(textNodeIndex) {
  
  // Поиск нужного варианта по его id
  const textNode = textNodes.find((textNode) => textNode.id === textNodeIndex);
  
  // Замена текста и изображения на странице
  question.innerText = textNode.text;
  imageElement.src = textNode.src;
  
  // Удаление кнопок
  while (optionButtonsElement.firstChild) {
    optionButtonsElement.removeChild(optionButtonsElement.firstChild);
  }
  
  // Перебор количества и текстового содержания для кнопок
  textNode.options.forEach((option) => {
    if (showOption(option)) {
	  // Создание новой кнопки
      const button = document.createElement("button");
	  button.innerText = option.text;
      button.classList.add("btn");
      button.addEventListener("click", () => selectOption(option));
      optionButtonsElement.appendChild(button);
    }
  });
}

// Показ кнопки
function showOption(option) {
  return option.requiredState == null || option.requiredState(state);
}


// Выбор варианта с помощью кнопки
function selectOption(option) {
  const nextTextNodeId = option.nextText;
  showQuestion(nextTextNodeId);
}

// Константа, которая содержит в себе массив, в котором лежат текст, изображение и варианты ответа
const textNodes = [
  {
    id: 1, 									
    text: `Здравствуй дорогой друг! Тебе скучно и одиноко? Наш тест состоит из нескольких вопросовы и предназанчен для того, чтобы решить оби твои проблемы.`,
	src: 'Картинки/Начало теста.png',
    options: [
      {
        text: `Начнём тест`,
        nextText: 2,
      },
    ],
  },
  {
    id: 2, 									
    text: `Итак 1 вопрос. Твоя девушка любит путешествия?`,
	src: 'Картинки/Путешествия.jpg',
    options: [
      {
        text: `Да, любит`,
        nextText: 3,
      },
      {
        text: `Нет, ей они не нравяться`,
        nextText: 4,
      },
    ],
  },
   {
    id: 3, 									
    text: `Твоей девушке есть 18?`,
	src: 'Картинки/18+ и паспорт.jpg',
    options: [
      {
        text: `Нет`,
        nextText: 5,
      },
      {
        text: `Да`,
        nextText: 6,
      },
    ],
  },
  {
    id: 5, 									
    text: `Друг, такое уже попахивает проблемами с полицией)`,
	src: 'Картинки/Затычка.jpg',
    options: [
      {
        text: `Давай начнём сначала`,
        nextText: 1,
      },
    ],
  },
  {
    id: 6, 									
    text: `Твоя девушка любит кошек?`,
	src: 'Картинки/Любовь к котам.jpg',
    options: [
      {
        text: `Да не нужны нам эти коты`,
        nextText: 7,
      },
      {
        text: `Да, конечно, коты это святое`,
        nextText: 11,
      },
    ],
  },
  {
    id: 7, 									
    text: `ВЫЙДИ ВОН!!!`,
	src: 'Картинки/Коты СВЯТОЕ!!!.jpg',
    options: [
      {
        text: `Начни заного и в следующий раз не обижай кошек`,
        nextText: 1,
      },

    ],
  },
  {
    id: 4, 									
    text: `Твоя девушка должна быть красивой?`,
	src: 'Картинки/Красивая девушка.jpg',
    options: [
	  {
        text: `Нет, красота ей ни к чему`,
        nextText: 8,
      },
	  {
        text: `Да, конечно она красивая`,
        nextText: 9,
      },
    ],
  },
  {
    id: 8, 									
    text: `ВСЕ ДЕВУШКИ КРАСИВЫЕ!!!`,
	src: 'Картинки/Не бывает не красивых женщин.jpg',
    options: [
	  {
        text: `Начни заного, и в следующий раз не оскорбляй девушек`,
        nextText: 1,
      },
    ],
  },
  {
    id: 9, 									
    text: `Твоя девушка принимала участие в спасении мира?`,
	src: 'Картинки/Затычка.jpg',
    options: [
      {
        text: `Нет, зачем мне девушка, которая спасала мир`,
        nextText: 10,
      },
      {
        text: 'Да, если спасла мир, значит и меня спасёт',
        nextText: 11,
      }
    ],
  },
  {
    id: 10, 									
    text: `Ну и как тебе живёться теперь???`,
	src: 'Картинки/Спасение мира.jpg',
    options: [
      {
        text: `Начни сначала, и в следующий раз подумай о спасении мира`,
        nextText: 1,
      },
    ],
  },
  {
    id: 11, 									
    text: `Какой размер груди у вашей девушки?`,
	src: 'Картинки/Фары слепят.jpg',
    options: [
      {
        text: `Большой`,
        nextText: 12,
      },
      {
        text: `Грудь это не главное`,
        nextText: 13
      }
    ],
  },
  {
    id: 12, 									
    text: `Вашу девушка обладает некой изюменкой?`,
	src: 'Картинки/Изюменка.jpg',
    options: [
      {
        text: `Да, конечно, девушка должна быть особенной`,
        nextText: 14,
      },
	  {
        text: `Нет, нам лишние особенности ни к чему`,
        nextText: 15,
      },
    ],
  },
  {
    id: 14, 									
    text: `Итак, твоя девушка Джозеф Джостар. Он имеет большую и широкую грудь, он НЕСОМНЕННО красив и обладает некой изюменкой. Тебе явно повезло)`,
	src: 'Картинки/Джозеф.jpg',
    options: [
      {
        text: `Можем начать сначала и подобрать тебе другую девушку`,
        nextText: 1,
      },
    ],
  },
    {
    id: 15, 									
    text: `Твоя девушка любит большие стволы?`,
	src: 'Картинки/Стволы.jpg',
    options: [
      {
        text: `Да, конечно, если девушка любит стволы, это хорошо`,
        nextText: 16,
      },
      {
        text: `Нет, стволы это явно лишние`,
        nextText: 17,
      }
    ],
  },
    {
    id: 16, 									
    text: `Поздравляю, твоей девушкой стенет Йоко Литтнер. Она красива, любит большие стволы, и вообще прекрасна.`,
	src: 'Картинки/Йоко.jpg',
    options: [
      {
        text: `Начнём сначала и подберём другую девушку, если она тебя не устраивает`,
        nextText: 1,
      },
    ],
  },
    {
    id: 17, 									
    text: `Не самый плохой вариант!`,
	src: 'Картинки/Без баб.jpg',
    options: [
      {
        text: `Давай начнём сначала`,
        nextText: 1,
      },
    ],
  },
  {
    id: 13, 									
    text: `Твоя девушка обладает взрывным характером?`,
	src: 'Картинки/Взрыв.png',
    options: [
      {
        text: `Нет, давайте что-нибудь по спокойнее`,
        nextText: 19,
      },
	  {
        text: `Да, конечно, энергичная девушка всегда привлекательна`,
        nextText: 18,
      },
    ],
  },
  {
    id: 19, 									
    text: `Твоей девушкой станет Рукия Кучики. Она спокойная и рассудительная. Тебе явно понравится`,
	src: 'Картинки/Рукия.jpeg',
    options: [
      {
        text: `Можем подобрать тебе другую, если тебя эта не устраивает`,
        nextText: 1,
      },
    ],
  },
  {
    id: 18, 									
    text: `Твоя девушка имеет красные рожки?`,
	src: 'Картинки/Рога.jpg',
    options: [
      {
        text: `Да, рожки выглядят миленько и являются неотъемлемой частью образа`,
        nextText: 20,
      },
      {
        text: `Нет, рожки это явно лишние`,
        nextText: 17,
      }
    ],
  },
  {
    id: 20, 									
    text: `Тебе досталась прекрасная девушка Пауэр!!! Она имеет взрывной характер, красные рожки, и все черты, необходимые настоящей девушке`,
	src: 'Картинки/Пауэр.jpg',
    options: [
      {
        text: `Если она тебя не устраивает, то можем попробовать подобрать другую`,
        nextText: 1,
      },
    ],
  },
];

showQuestion(1);
